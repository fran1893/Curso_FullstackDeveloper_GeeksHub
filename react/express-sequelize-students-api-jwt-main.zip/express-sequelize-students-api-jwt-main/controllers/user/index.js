const userController = {};

userController.getAll = require("./getAll");


module.exports = userController;
