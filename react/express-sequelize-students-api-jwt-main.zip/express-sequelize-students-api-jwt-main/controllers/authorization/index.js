const authController = {};

authController.registerAlumno = require("./registerAlumno");
authController.login = require("./login");

module.exports = authController;
